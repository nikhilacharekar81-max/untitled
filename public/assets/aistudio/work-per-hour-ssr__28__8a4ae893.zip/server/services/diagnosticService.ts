import { randomUUID } from 'crypto';
import { postgresStore, isPostgresEnabled } from '../db/postgresStore.js';
import fs from 'fs';
import path from 'path';

const LOGS_DIR = path.resolve(process.cwd(), 'logs123');
if (!fs.existsSync(LOGS_DIR)) {
  fs.mkdirSync(LOGS_DIR, { recursive: true });
}

export type DiagnosticSeverity = 'INFO' | 'WARN' | 'ERROR';

class DiagnosticService {
  private queue: any[] = [];
  private readonly MAX_QUEUE_SIZE = 100;

  async log(
    severity: DiagnosticSeverity,
    service: string,
    functionName: string,
    implementation: string | null,
    operation: string,
    outcome: string,
    details: any,
    error: any = null
  ) {
    const entry = {
      id: randomUUID(),
      timestamp: new Date().toISOString(),
      severity,
      service,
      functionName,
      implementation,
      operation,
      outcome,
      errorMessage: error ? String(error.message || error) : null,
      details: details || {}
    };

    if (this.queue.length < this.MAX_QUEUE_SIZE) {
      this.queue.push(entry);
    }
    this.flush();
    this.exportToFile(entry);
  }

  private async flush() {
    if (!isPostgresEnabled() || this.queue.length === 0) return;
    
    const entriesToFlush = [...this.queue];
    this.queue = [];

    try {
      await postgresStore.executeInTransaction(async (client: any) => {
        for (const entry of entriesToFlush) {
          await client.query(
            `INSERT INTO runtime_diagnostic_logs (id, timestamp, severity, service, function_name, implementation, operation, outcome, error_message, details)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
            [
              entry.id, entry.timestamp, entry.severity, entry.service, entry.functionName,
              entry.implementation, entry.operation, entry.outcome, entry.errorMessage, JSON.stringify(entry.details)
            ]
          );
        }
      });
    } catch (err) {
      console.error('[DiagnosticService] Postgres flush failed:', err);
    }
  }

  private exportToFile(entry: any) {
    try {
      const logLine = JSON.stringify(entry) + '\n';
      fs.appendFileSync(path.join(LOGS_DIR, 'runtime-diagnostics.txt'), logLine);
    } catch (err) {
      console.error('[DiagnosticService] File export failed:', err);
    }
  }
}

export const diagnosticService = new DiagnosticService();
